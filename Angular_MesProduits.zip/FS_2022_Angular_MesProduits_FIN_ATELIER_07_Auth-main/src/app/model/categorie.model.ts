export class Categorie {
    idCat! : number; // ou idCat? : number;
    nomCat! : string;
    }